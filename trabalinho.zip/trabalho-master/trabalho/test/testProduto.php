<?php

 require '../app/modelos/produtos.php';


    $p1 = new Produto( )